from django import forms
from .models import Post

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        exclude = ('published_date',)
        fields = '__all__'
        widgets = {
            'class_standing': forms.RadioSelect(),
            'known_programming_languages': forms.CheckboxSelectMultiple,
            'comments': forms.Textarea(),
            
        }
        
