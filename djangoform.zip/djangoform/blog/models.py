from django.conf import settings
from django.db import models
from django.utils import timezone
from django import forms


class Post(models.Model):
    published_date = models.DateTimeField(blank=True, null=True)
    class Major_Choices(models.TextChoices):
        Computer_Science = 'CS', 'Computer Science'
        Software_Development = 'SD', 'Software Development'
        Other = 'O', 'Other'
    
    LANGUAGE_CHOICE = [
        ("python", "Python"),
        ("c++", "C++"),
        ("others", "Others"),
        ("none", "None"),
    ]
    CLASS_CHOICES = [
        ("1", "Top 1%"),
        ("2", "Top 5%"),
        ("3", "Top 10%"),
        ("4", "Top 25%"), 
        ("5", "Top 50%"),
        ("6", "Top 90%"),
        ("7", "None/Unknown")
    ]
    
    student_name = models.CharField(max_length=100,default="")
    student_id = models.CharField(max_length=100,default="")
    major = models.CharField(choices=Major_Choices.choices,default="O")
    class_standing = models.CharField(choices=CLASS_CHOICES, default="")
    known_programming_languages = models.CharField(choices=LANGUAGE_CHOICE,default="")
    expected_graduation_year = models.IntegerField(default="")
    comments = models.CharField(default="")
    

    def publish(self):
        self.published_date = timezone.now()
        self.save()

    def __str__(self):
        return self.title